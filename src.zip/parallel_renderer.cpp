/// @file
////////////////////////////////////////////////////////////////////////////////////////////////////
///
/// Copyright (C) 2016/17      Christian Lessig, Otto-von-Guericke Universitaet Magdeburg
///
////////////////////////////////////////////////////////////////////////////////////////////////////
///
///  module     : Exercise 1
///
///  author     : lessig@isg.cs.ovgu.de
///
///  project    : GPU Programming
///
///  description: parallel renderer
///
////////////////////////////////////////////////////////////////////////////////////////////////////

// includes, file
#include "parallel_renderer.h"

// includes, system
#include <iostream>
#include <thread>
#include <chrono>


////////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor, default
////////////////////////////////////////////////////////////////////////////////////////////////////
ParallelRenderer::ParallelRenderer() :
  Renderer()
{ }

////////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
////////////////////////////////////////////////////////////////////////////////////////////////////
ParallelRenderer::~ParallelRenderer() { }

////////////////////////////////////////////////////////////////////////////////////////////////////
// Initialize
////////////////////////////////////////////////////////////////////////////////////////////////////
void ParallelRenderer::init( Camera* cam_cur, Scene* scene_cur) {

  // TODO: determine available hardware capabilities
    unsigned num_threads = std::thread::hardware_concurrency();

	std::cout << "Using " << num_threads << " threads." << std::endl;

	Renderer::init( cam_cur, scene_cur);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Initialize
////////////////////////////////////////////////////////////////////////////////////////////////////
void ParallelRenderer::init( Camera* cam_cur, Scene* scene_cur, const unsigned int nt) {

  num_threads = nt;
  
  std::cout << "Using " << num_threads << " threads." << std::endl;

  Renderer::init( cam_cur, scene_cur);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// render a single tile
////////////////////////////////////////////////////////////////////////////////////////////////////
void ParallelRenderer::renderTile( const ivec2 tid, const ivec2& num_threads) {

	// TODO: render tile
	unsigned int tileWidth = this->cam->image.n_cols / num_threads[0];
    unsigned int tileHeight = this->cam->image.n_rows / num_threads[1];


		unsigned int ix1 = tid[0] * tileWidth;
		unsigned int ix2 = (tid[0]+1) * tileWidth;

		unsigned int iy1 = tid[1] * tileHeight;
		unsigned int iy2 = (tid[1]+1) * tileHeight;

		Ray* ray = new Ray();
		Intersection* intersec = new Intersection();

		for (unsigned int i = ix1; i < ix2; ++i) {
			for (unsigned int j = iy1; j < iy2; ++j) {
				cam->generateRay(i,j,*ray);

				if(scene->traceRay(*ray, *intersec)){
					this->cam->image(i,j) =  shade(*intersec);
				}
			}
		}
	    delete(ray);
        delete(intersec);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// render
////////////////////////////////////////////////////////////////////////////////////////////////////
void ParallelRenderer::render() {

	// TODO: determine tile layout

    int lg = std::log2(num_threads);
    int x_pow = lg/2;
    int y_pow = lg-x_pow;
    num_tiles[0] = static_cast<int>(pow(2,x_pow));
    num_tiles[1] = static_cast<int>(pow(2,y_pow));

	std::cerr << "ParallelRenderer::render() : running with " << num_tiles[0] << " * " << num_tiles[1] << " Tiles." << std::endl;

	// starting point
	auto t_start = std::chrono::high_resolution_clock::now();

	// TODO: spawn threads
	std::vector<std::thread> threads;
	for(int i = 0; i < num_tiles[0]; i++) {
		for (int j = 0; j < num_tiles[1]; j++) {
            const ivec2 tid(i,j);
			threads.push_back(std::thread(&ParallelRenderer::renderTile, this, tid, num_tiles));
			}
		}
		for(unsigned int i = 0; i < num_tiles[0]*num_tiles[1]; ++i) threads[i].join();
  // ending point
  auto t_end = std::chrono::high_resolution_clock::now();
  // calculate elapsed time
  double wall_clock = std::chrono::duration<double, std::milli>(t_end-t_start).count();
  std::cerr << "Rendering took " <<  wall_clock << " ms."<< std::endl;
}
