/// @file
////////////////////////////////////////////////////////////////////////////////////////////////////
///
/// Copyright (C) 2016/17      Christian Lessig, Otto-von-Guericke Universitaet Magdeburg
///
////////////////////////////////////////////////////////////////////////////////////////////////////
///
///  module     : lecture 3
///
///  author     : lessig@isg.cs.ovgu.de
///
///  project    : GPU Programming
///
///  description: race conditions
///
////////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <vector>
#include <thread>
#include <cstdlib>
#include <cmath>

std::mutex mutex_sum;

////////////////////////////////////////////////////////////////////////////////////////////////////
// add two vectors together
////////////////////////////////////////////////////////////////////////////////////////////////////
void
compute_norm( unsigned int tid, unsigned int num_threads, float* a, int n, float& sum) {

  unsigned int delta = n / num_threads;
  unsigned int i1 = tid * delta;
  unsigned int i2 = (tid+1) * delta;

  float sum_loc = 0;
  for( unsigned int i = i1; i < i2; ++i) {
    sum_loc += a[i] * a[i];
  }

  mutex_sum.lock();
  sum += sum_loc;
  mutex_sum.unlock();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// program entry point
////////////////////////////////////////////////////////////////////////////////////////////////////
int
main( int /*argc*/, char** /*argv*/ ) {

  const unsigned int n = 2 << 22;

  float* a = (float*) malloc( n * sizeof(float));
  for( unsigned int i = 0; i < n; ++i) {
    a[i] = 1.0 / static_cast<float>(i+1);
  }

  float sum1 = 0.0;
  float sum2 = 0.0;

  {
    unsigned int num_threads = 4;
    std::vector< std::thread > threads;
    for( unsigned int i = 0; i < num_threads; ++i) {
      threads.push_back( std::thread( compute_norm, i, num_threads, a, n, std::ref(sum1)));
    }

    for( unsigned int i = 0; i < num_threads; ++i) {
      threads[i].join();
    }
  }

  {
    unsigned int num_threads = 32;
    std::vector< std::thread > threads;
    for( unsigned int i = 0; i < num_threads; ++i) {
      threads.push_back( std::thread( compute_norm, i, num_threads, a, n, std::ref(sum2)));
    }

    for( unsigned int i = 0; i < num_threads; ++i) {
      threads[i].join();
    }
  }

  float norm1 = std::sqrt( sum1);
  float norm2 = std::sqrt( sum2);
  if( std::abs(norm1 - norm2) / norm2 < (2*n+1)*std::numeric_limits<float>::epsilon()) {
    std::cerr << "ERROR : error is too large to be explained by floating point inaccuracy"
              << std::endl;
  }

  std::cerr << std::scientific << std::setprecision(8);
  std::cerr << "norm(a) = " << norm1 << std::endl;
  std::cerr << "norm(a) = " << norm2 << std::endl;

  free( a);

  return EXIT_SUCCESS;
}
