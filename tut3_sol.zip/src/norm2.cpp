/// @file
////////////////////////////////////////////////////////////////////////////////////////////////////
///
/// Copyright (C) 2016/17      Christian Lessig, Otto-von-Guericke Universitaet Magdeburg
///
////////////////////////////////////////////////////////////////////////////////////////////////////
///
///  module     : lecture 3
///
///  author     : lessig@isg.cs.ovgu.de
///
///  project    : GPU Programming
///
///  description: race conditions
///
////////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <vector>
#include <thread>
#include <cstdlib>
#include <cmath>

std::mutex mutex_sum;

////////////////////////////////////////////////////////////////////////////////////////////////////
// add two vectors together
////////////////////////////////////////////////////////////////////////////////////////////////////
void
compute_norm( unsigned int tid, unsigned int num_threads, int* a, int n, int& sum) {

  unsigned int delta = n / num_threads;
  unsigned int i1 = tid * delta;
  unsigned int i2 = (tid+1) * delta;

  int sum_loc = 0;
  for( unsigned int i = i1; i < i2; ++i) {
    sum_loc += a[i] * a[i];
  }

  mutex_sum.lock();
  sum += sum_loc;
  mutex_sum.unlock();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// program entry point
////////////////////////////////////////////////////////////////////////////////////////////////////
int
main( int /*argc*/, char** /*argv*/ ) {

  const unsigned int n = 2 << 22;
  const unsigned int num_threads = 4;

  int* a = (int*) malloc( n * sizeof(int));
  for( unsigned int i = 0; i < n; ++i) {
    a[i] = 1;
  }

  int sum = 0;

  std::vector< std::thread > threads;
  for( unsigned int i = 0; i < num_threads; ++i) {
    threads.push_back( std::thread( compute_norm, i, num_threads, a, n, std::ref(sum)));
  }

  for( unsigned int i = 0; i < num_threads; ++i) {
    threads[i].join();
  }

  std::cerr << "norm(a) = " << std::sqrt( (float) sum) << std::endl;

  free( a);

  return EXIT_SUCCESS;
}
